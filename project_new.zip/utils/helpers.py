import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def greet(name):
    logger.info("Calling greet function with name: %s", name)
    try:
        return f"Hello, {name}! Welcome to the project."
    except Exception as e:
        logger.error("Error in greet function: %s", str(e))
        raise