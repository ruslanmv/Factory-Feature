def greet(name, location=None):
    """
    Returns a greeting message for the provided name.

    Args:
        name: The name of the person to greet.
        location: The location of the person (optional).

    Returns:
        A greeting string.
    """
    if location:
        return f"Hello, {name}! Welcome to {location}."
    else:
        return f"Hello, {name}! Welcome to the project."