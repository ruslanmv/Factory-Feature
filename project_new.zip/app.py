import logging
from utils.helpers import greet

logging.basicConfig(filename='app.log', filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

def main():
    try:
        name = input("Enter your name: ")
        logging.info(f"User entered: {name}")
        print(greet(name))
    except Exception as e:
        logging.error(f"An error occurred: {e}")

if __name__ == "__main__":
    main()