from utils.helpers import greet, get_age

def main():
    name = input("Enter your name: ")
    age = int(input("Enter your age: "))
    print(greet(name, age))

if __name__ == "__main__":
    main()